# max argument

    Code
      print(num(1:10), max = 5)
    Output
      <pillar_num[10]>
      [1] 1 2 3 4 5
      ... and 5 more
    Code
      print(char(letters), max = 10)
    Output
      <pillar_char[26]>
       [1] a b c d e f g h i j
      ... and 16 more

# max.print option

    Code
      num(1:10)
    Output
      <pillar_num[10]>
      [1] 1 2 3
      ... and 7 more
    Code
      char(letters)
    Output
      <pillar_char[26]>
      [1] a b c
      ... and 23 more

