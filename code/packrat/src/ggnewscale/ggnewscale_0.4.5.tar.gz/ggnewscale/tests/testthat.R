library(testthat)
library(ggnewscale)

test_check("ggnewscale")
