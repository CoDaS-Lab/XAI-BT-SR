library(testthat)
library(vdiffr)
library(interactions)

test_check("interactions")
